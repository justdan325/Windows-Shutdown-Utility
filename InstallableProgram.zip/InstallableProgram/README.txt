----------------------Automatic Shutdown for Windows 2.0------------------------

Thank you for trying my program: Automatic Shutdown for Windows.

This program was intended for Windows Vista or later.

To use this program, you must have Java SE 8 or later installed.

Do not modify/run any of the files in the "AutoShutdown" subdirectory.

To install this program, use the "InstallerScript.bat" script in this 
directory.



This program has been released under GPL 3.0; if you wish to make any
modifications, the source code is available on Github.